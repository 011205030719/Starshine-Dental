<?php
//Database & Login Credentials.
$dbHost = "localhost";
$dbUsername = "starshine";
$dbPassword = "starshine@2023";
$dbDatabase = "starshine";

$db = mysqli_connect("$dbHost","$dbUsername","$dbPassword") or 
	die("<br><center><font face='arial'>Unable to connect to MySQL Server.<br>".mysqli_error()."</font></center>");
mysqli_select_db($db,"$dbDatabase") or 
	die("<br><center><font face='arial'>Unable to connect to database.<br>".mysqli_error()."</font></center>");
?>